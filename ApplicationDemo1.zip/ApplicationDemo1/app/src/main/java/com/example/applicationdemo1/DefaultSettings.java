package com.example.applicationdemo1;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.io.UnsupportedEncodingException;

public class DefaultSettings extends AppCompatActivity {
    Button b1,b2,b3;
    Switch m,r,d,w;
    String defaultsettingsstring;
    SeekBar Rp,Gp,Bp;

   int mstat=0;
   int  dstat=0;
    int rstat=0;
    int wstat=0;
    String Red,Blue,Green;
    TextView tx1;
    static String MQTTHOST ="tcp://192.168.5.26:1883";

    String topicStr= "Doorp";
    MqttAndroidClient client;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_default_settings);
        String clientId = MqttClient.generateClientId();
        client = new MqttAndroidClient(this.getApplicationContext(), MQTTHOST, clientId);
        MqttConnectOptions options = new MqttConnectOptions();



        try {
            IMqttToken token = client.connect(options);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    Toast.makeText(DefaultSettings.this, "connected",Toast.LENGTH_LONG).show();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    Toast.makeText(DefaultSettings.this, "connection failed",Toast.LENGTH_LONG).show();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
        b1 = findViewById(R.id.button2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomePage();
            }
        });
        b2 = findViewById(R.id.button);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pub("profiles","Default");
                LogOut();
            }
        });
        b3 = findViewById(R.id.publishbut);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                defaultsettingsstring=(Integer.toString(dstat)+Integer.toString(wstat)+Integer.toString(mstat)+Integer.toString(rstat)+Red+Blue+Green);
                pub("Settings",defaultsettingsstring);
            }
        });
        d = findViewById(R.id.switchd);
        d.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                   dstat=1;
                }
                else {
                    dstat=0;
                }
            }
        });

        w = findViewById(R.id.switchw);
        m = findViewById(R.id.switchm);
        r = findViewById(R.id.switchr);
        w.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    wstat=1;
                }
                else {
                    wstat =0;
                }
            }
        });
        m.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                   mstat=1;
                }
                else {
                    mstat=0;
                }
            }
        });
        r.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                   rstat=1;
                }
                else {
                    rstat=0;
                }
            }
        });

        Rp=(SeekBar)findViewById(R.id.rpseek);
        Gp=(SeekBar)findViewById(R.id.gpseek);
        Bp=(SeekBar)findViewById(R.id.bpseek);
        // perform seek bar change listener event used for getting the progress value
        Rp.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressChangedValue = 0;
            int redvalue;
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;

            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                int redvalue=(progressChangedValue*254/100)+1;
                if (redvalue<10) {
                    Red = "00"+Integer.toString(redvalue);
                }
                else if (redvalue<100){
                    Red = "0"+Integer.toString(redvalue);
                }
                else {
                    Red = Integer.toString(redvalue);
                }

                Toast.makeText(DefaultSettings.this, "Red Value is :" + redvalue ,
                        Toast.LENGTH_SHORT).show();
            }
        });
        Gp.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressChangedValue = 0;
            int greenvalue;
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;

            }

            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                int greenvalue=(progressChangedValue*254/100)+1;
                if (greenvalue<10) {
                    Green = "00"+Integer.toString(greenvalue);
                }
                else if (greenvalue<100){
                    Green = "0"+Integer.toString(greenvalue);
                }
                else {
                    Green = Integer.toString(greenvalue);
                }

                Toast.makeText(DefaultSettings.this, "Green Value is :" +greenvalue,
                        Toast.LENGTH_SHORT).show();
            }
        });
        Bp.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int progressChangedValue = 0;
            int bluevalue;

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                progressChangedValue = progress;
                int bluenvalue=(progressChangedValue*254/100)+1;
            }

            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
                int bluevalue=(progressChangedValue*255/100);
                if (bluevalue<10) {
                    Blue = "00"+Integer.toString(bluevalue);
                }
                else if (bluevalue<100){
                    Blue = "0"+Integer.toString(bluevalue);
                }
                else {
                    Blue = Integer.toString(bluevalue);
                }

                Toast.makeText(DefaultSettings.this, "Blue Value is :" + bluevalue,
                        Toast.LENGTH_SHORT).show();
            }
        });



    }




    public void openHomePage() {
        Intent intent = new Intent(this, Push.class);
        startActivity(intent);
    }
    public void LogOut() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void pub (String topic1,String msg) {
        String topic = topic1;
        String message = msg;
        try {
            client.publish(topic1, message.getBytes(),0,false);
        } catch ( MqttException e) {
            e.printStackTrace();
        }
    }
}
